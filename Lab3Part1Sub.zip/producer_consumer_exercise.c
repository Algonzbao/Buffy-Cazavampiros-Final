#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>



#define MAX_COMPOSITIONS 5 // Maximum items a producer can produce or a consumer can consume
#define MAX_PLAYS        5 // Maximum items a producer can produce or a consumer can consume
#define BUFFER_SIZE 5 // Size of the buffer

int in = 0;
int out = 0;
int buffer[BUFFER_SIZE];

pthread_mutex_t mutex;
sem_t bufferfull;
sem_t bufferempty;

void *composer(void *composer_name)
{   
    int work;
    for(int i = 0; i < MAX_COMPOSITIONS; i++) {
    	sem_wait(&bufferfull); 
    	pthread_mutex_lock(&mutex);
        work = rand(); 
        
        buffer[in] = work;
        printf("Composer %s: Insert work at position %d\n", (char*)composer_name, in);
        in = (in+1)%BUFFER_SIZE;
        pthread_mutex_unlock(&mutex);
        sem_post(&bufferempty);
    }
}
void *player(void *player_name)
{   
    for(int i = 0; i < MAX_PLAYS; i++) {
    	sem_wait(&bufferempty); 
    	pthread_mutex_lock(&mutex);
        int item = buffer[out];
        printf("Player %s: Plays work from position %d\n", (char*)player_name, out);
        out = (out+1)%BUFFER_SIZE;
        pthread_mutex_unlock(&mutex);
        sem_post(&bufferfull);
    }
}

int main()
{   
    pthread_t composer_thread[5], player_thread[5];

    const char *composer_array[5] = {"Mozart", "Bach", "Haendel", "Beethoven", "Wagner"}; 
    const char *player_array[5]   = {"Wolfgang Meye", "Hans-Peter Westermann", "Robert Wolf", "Naoko Yoshino", "Nikolaus Harnoncourt"}; 

	pthread_mutex_init(&mutex, NULL);
	sem_init(&bufferfull, 0, BUFFER_SIZE);
	sem_init(&bufferempty, 0, 0);
	
    
    for(int i = 0; i < 5; i++) {
        pthread_create(&composer_thread[i], NULL, (void *)composer, (void *)composer_array[i]);
    }
    
    for(int i = 0; i < 5; i++) {
        pthread_create(&player_thread[i], NULL, (void *)player, (void *)player_array[i]);
    }

    for(int i = 0; i < 5; i++) {
        pthread_join(composer_thread[i], NULL);
    }
    for(int i = 0; i < 5; i++) {
        pthread_join(player_thread[i], NULL);
    }
    
    pthread_mutex_destroy(&mutex);
    sem_destroy(&bufferempty);
    sem_destroy(&bufferfull);

    return 0;
    
}
